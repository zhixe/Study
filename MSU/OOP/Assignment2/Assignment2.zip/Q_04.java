package MSU.OOP.Assignment2; // Set current working directory.
import MSU.OOP.Assignment2.classes.strClass; // Import strClass class from local directory.

public class Q_04 // Construct java main class for OOP A2 Question 4
{
    public static void Q4() throws InterruptedException      
    {
        strClass mainStr = new strClass(); // Assign mainStr as a strClass class variable and instantiate a new object to a strClass class constructor which initializes the new object.
        mainStr.Str_class(); // Call the class method Str_class() from mainStr variable. This will run the whole process of strClass class.
    }
}